import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/app_user.dart';
import '../services/pocketbase_client.dart';

/// Authentication state. Persists the PocketBase token across launches and
/// exposes the current provider user.
class AuthState extends ChangeNotifier {
  AuthState(this._prefs) {
    _pb.setToken(_prefs.getString(_kToken));
    _loadCachedUser();
  }

  final SharedPreferences _prefs;
  final PocketBaseClient _pb = PocketBaseClient();

  static const _kToken = 'pb_token';
  static const _kUser = 'pb_user';

  AppUser? _user;
  bool _loading = false;
  String? _error;

  AppUser? get user => _user;
  bool get isAuthed => _pb.isAuthed && _user != null;
  bool get loading => _loading;
  String? get error => _error;
  PocketBaseClient get pb => _pb;

  Future<void> _loadCachedUser() async {
    final raw = _prefs.getString(_kUser);
    if (raw == null || raw.isEmpty) return;
    try {
      final decoded = jsonDecode(raw);
      if (decoded is Map<String, dynamic>) {
        _user = AppUser.fromRecord(decoded);
        notifyListeners();
      }
    } catch (_) {}
  }

  /// Login with email or mobile + password.
  Future<bool> login(String identity, String password) async {
    _loading = true;
    _error = null;
    notifyListeners();
    try {
      final body = await _pb.authWithPassword(identity.trim(), password);
      final record = body['record'] as Map<String, dynamic>?;
      if (record == null) {
        _error = 'No account record returned.';
        _loading = false;
        notifyListeners();
        return false;
      }
      final u = AppUser.fromRecord(record);
      if (!['doctor', 'nursing', 'physio', 'attendant', 'dietitian', 'psychologist']
          .contains(u.role)) {
        await logout();
        _error =
            'This account is a ${u.role.isEmpty ? "unknown" : u.role} role. Use the website for non-provider accounts.';
        _loading = false;
        notifyListeners();
        return false;
      }
      _user = u;
      await _prefs.setString(_kToken, _pb.token ?? '');
      await _prefs.setString(_kUser, jsonEncode(record));
      _loading = false;
      notifyListeners();
      return true;
    } on PbException catch (e) {
      _error = (e.message.contains('Failed to authenticate') ||
              e.message.contains('invalid login'))
          ? 'Invalid email/mobile or password.'
          : e.message;
      _loading = false;
      notifyListeners();
      return false;
    } catch (e) {
      _error = 'Could not connect. Check your internet and try again.';
      _loading = false;
      notifyListeners();
      return false;
    }
  }

  Future<void> logout() async {
    _pb.clearToken();
    _user = null;
    await _prefs.remove(_kToken);
    await _prefs.remove(_kUser);
    notifyListeners();
  }

  /// Refresh the auth record from the server (e.g. after profile edits).
  Future<void> refreshUser() async {
    if (!isAuthed) return;
    try {
      final body = await _pb.authRefresh();
      final record = body['record'] as Map<String, dynamic>?;
      if (record != null) {
        _user = AppUser.fromRecord(record);
        await _prefs.setString(_kToken, _pb.token ?? '');
        await _prefs.setString(_kUser, jsonEncode(record));
        notifyListeners();
      }
    } catch (_) {
      // Token may be expired — keep cached user.
    }
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}
