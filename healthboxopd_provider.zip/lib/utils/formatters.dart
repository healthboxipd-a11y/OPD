import 'package:intl/intl.dart';

/// Format an INR amount like the website: ₹1,299
String formatINR(num? n) {
  return '₹${NumberFormat.decimalPattern('en_IN').format((n ?? 0).toDouble().round())}';
}

/// Format a Healthbox ID: PT1234567890 -> "PT 12345 67890".
String formatUniqueId(String? id) {
  final v = (id ?? '').trim();
  if (v.isEmpty) return '—';
  if (RegExp(r'^[A-Z]{2}\d{10}$').hasMatch(v)) {
    return '${v.substring(0, 2)} ${v.substring(2, 7)} ${v.substring(7)}';
  }
  if (v.length == 10 && RegExp(r'^\d{10}$').hasMatch(v)) {
    return '${v.substring(0, 5)} ${v.substring(5)}';
  }
  return v;
}

/// Local YYYY-MM-DD date string (not UTC).
String localIsoDate(DateTime now) {
  final y = now.year.toString();
  final m = now.month.toString().padLeft(2, '0');
  final d = now.day.toString().padLeft(2, '0');
  return '$y-$m-$d';
}

/// Pretty date+time for display.
String formatDateTime(String? iso) {
  if (iso == null || iso.isEmpty) return '—';
  final dt = DateTime.tryParse(iso);
  if (dt == null) return iso;
  return DateFormat('d MMM yyyy, h:mm a').format(dt.toLocal());
}

String formatDate(String? iso) {
  if (iso == null || iso.isEmpty) return '—';
  final dt = DateTime.tryParse(iso);
  if (dt == null) return iso;
  return DateFormat('d MMM yyyy').format(dt.toLocal());
}

/// Normalize a 10-digit Indian mobile number. Returns '' if invalid.
String normalizeMobile(String value) {
  var digits = value.replaceAll(RegExp(r'\D'), '');
  if (digits.length == 12 && digits.startsWith('91')) digits = digits.substring(2);
  if (digits.length == 11 && digits.startsWith('0')) digits = digits.substring(1);
  return RegExp(r'^[6-9]\d{9}$').hasMatch(digits) ? digits : '';
}

bool isMobileIdentifier(String value) {
  final v = value.trim();
  if (v.isEmpty || v.contains('@')) return false;
  return normalizeMobile(v).isNotEmpty;
}

/// Map a mobile number to the synthetic mailbox used by the backend.
String identifierToEmail(String value) {
  final v = value.trim();
  if (v.contains('@')) return v.toLowerCase();
  final phone = normalizeMobile(v);
  if (phone.isNotEmpty) return '91$phone@mobile.healthboxopd.in';
  return v.toLowerCase();
}

bool isSyntheticEmail(String? email) {
  return (email ?? '').endsWith('@mobile.healthboxopd.in');
}

/// Email shown to the user — hides the synthetic mobile mailbox.
String displayEmail(String? email) {
  if (email == null || email.isEmpty) return '';
  if (isSyntheticEmail(email)) return '';
  return email;
}

/// Human label for a booking/service status.
String statusLabel(String? status) {
  const map = {
    'pending': 'Pending',
    'confirmed': 'Confirmed',
    'assigned': 'Assigned',
    'in_progress': 'In Progress',
    'completed': 'Completed',
    'cancelled': 'Cancelled',
    'unpaid': 'Payment pending',
    'paid': 'Paid',
    'refunded': 'Refunded',
    'requested': 'Requested',
    'processing': 'Processing',
    'settled': 'Settled',
    'rejected': 'Rejected',
    'resubmit': 'Resubmit required',
    'cleared': 'Verified',
    'pending_review': 'Under review',
  };
  return map[status ?? ''] ?? (status ?? '—');
}

/// Service name from a service id (mirrors website SERVICES).
String serviceName(String? id) {
  const map = {
    'opd_center': 'OPD at Center',
    'opd_home': 'OPD at Home',
    'ipd': 'IPD Admission',
    'attendant': 'Patient Attendant',
    'attendant_baby': 'Attendant & Baby Care',
    'nursing': 'Nursing Services',
    'home_care': 'Home Care Services',
    'physio': 'Physiotherapist at Home',
  };
  return map[id ?? ''] ?? (id ?? '—');
}

/// Department + specialization display label.
String departmentSpecialization(String? department, String? specialization) {
  final d = (department ?? '').trim();
  final s = (specialization ?? '').trim();
  if (d.isEmpty && s.isEmpty) return '';
  if (d.isEmpty) return s;
  if (s.isEmpty) return d;
  return '$d · $s';
}
