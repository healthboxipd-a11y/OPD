import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../config.dart';
import '../models/app_user.dart';
import '../state/app_state.dart';
import '../state/auth_state.dart';
import '../utils/theme.dart';
import '../widgets/common.dart';
import 'appointments_screen.dart';
import 'availability_screen.dart';
import 'earnings_screen.dart';
import 'overview_screen.dart';
import 'profile_screen.dart';

/// Main shell with a bottom navigation bar. Role-aware labels.
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final auth = context.read<AuthState>();
      final app = context.read<AppState>();
      app.load(auth);
      app.startPolling(auth);
    });
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthState>();
    final app = context.watch<AppState>();
    final user = auth.user;
    if (user == null) return const SizedBox.shrink();

    final isDoctor = user.isDoctor;
    final tabs = <_Tab>[
      _Tab('Overview', Icons.dashboard_outlined, OverviewScreen.new),
      _Tab(
        isDoctor ? 'Appointments' : 'Assignments',
        Icons.calendar_today_outlined,
        AppointmentsScreen.new,
      ),
      _Tab('Availability', Icons.schedule_outlined, AvailabilityScreen.new),
      _Tab('Earnings', Icons.account_balance_wallet_outlined, EarningsScreen.new),
      _Tab('Profile', Icons.person_outline, ProfileScreen.new),
    ];

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: AppTheme.primary,
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(Icons.favorite, color: Colors.white, size: 16),
            ),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('HealthboxOPD',
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
                Text(
                  kRoleLabels[user.role] ?? user.role,
                  style: const TextStyle(fontSize: 11, color: AppTheme.muted),
                ),
              ],
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'Refresh',
            onPressed: () => app.load(auth),
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Logout',
            onPressed: () => _confirmLogout(context, auth),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () => app.load(auth),
        child: tabs[_index].builder(context),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _index,
        onTap: (i) => setState(() => _index = i),
        items: tabs
            .map((t) => BottomNavigationBarItem(
                  icon: Icon(t.icon),
                  label: t.label,
                ))
            .toList(),
      ),
    );
  }

  Future<void> _confirmLogout(BuildContext context, AuthState auth) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Sign out'),
        content: const Text('Sign out of your HealthboxOPD provider account?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: TextButton.styleFrom(foregroundColor: AppTheme.destructive),
            child: const Text('Sign out'),
          ),
        ],
      ),
    );
    if (ok == true) {
      context.read<AppState>().stopPolling();
      await auth.logout();
    }
  }
}

class _Tab {
  _Tab(this.label, this.icon, this.builder);
  final String label;
  final IconData icon;
  final Widget Function(BuildContext) builder;
}
