import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../config.dart';
import '../models/app_user.dart';
import '../state/auth_state.dart';
import '../utils/formatters.dart';
import '../utils/theme.dart';
import '../widgets/status_badge.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _name;
  late TextEditingController _phone;
  late TextEditingController _specialization;
  late TextEditingController _department;
  late TextEditingController _experience;
  late TextEditingController _workplace;
  late TextEditingController _city;
  late TextEditingController _state;
  late TextEditingController _pincode;
  late TextEditingController _address;
  late TextEditingController _fee;
  late TextEditingController _bankName;
  late TextEditingController _bankAccountName;
  late TextEditingController _bankAccountNumber;
  late TextEditingController _bankIfsc;
  late TextEditingController _bankBranch;

  File? _avatar;
  File? _panDoc;
  File? _aadhaarFront;
  File? _aadhaarBack;
  File? _aadhaarE;
  File? _certificate;
  File? _nmcCert;
  File? _smcCert;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final u = context.read<AuthState>().user!;
    _name = TextEditingController(text: u.name);
    _phone = TextEditingController(text: u.phone);
    _specialization = TextEditingController(text: u.specialization);
    _department = TextEditingController(text: u.department);
    _experience = TextEditingController(text: u.experience?.toString() ?? '');
    _workplace = TextEditingController(text: u.workplace);
    _city = TextEditingController(text: u.city);
    _state = TextEditingController(text: u.state);
    _pincode = TextEditingController(text: u.pincode);
    _address = TextEditingController(text: u.address);
    _fee = TextEditingController(text: u.fee?.toString() ?? '');
    _bankName = TextEditingController(text: u.bankName);
    _bankAccountName = TextEditingController(text: u.bankAccountName);
    _bankAccountNumber = TextEditingController(text: u.bankAccountNumber);
    _bankIfsc = TextEditingController(text: u.bankIfsc);
    _bankBranch = TextEditingController(text: u.bankBranch);
  }

  @override
  void dispose() {
    for (final c in [
      _name, _phone, _specialization, _department, _experience, _workplace,
      _city, _state, _pincode, _address, _fee, _bankName, _bankAccountName,
      _bankAccountNumber, _bankIfsc, _bankBranch,
    ]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<File?> _pick(ImageSource source) async {
    final picker = ImagePicker();
    final x = await picker.pickImage(source: source, imageQuality: 80);
    return x == null ? null : File(x.path);
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final auth = context.read<AuthState>();
    setState(() => _saving = true);
    try {
      final fields = <String, String>{
        'name': _name.text.trim(),
        'phone': _phone.text.trim(),
        'specialization': _specialization.text.trim(),
        'department': _department.text.trim(),
        'experience': _experience.text.trim().isEmpty ? '0' : _experience.text.trim(),
        'workplace': _workplace.text.trim(),
        'city': _city.text.trim(),
        'state': _state.text.trim(),
        'pincode': _pincode.text.trim(),
        'address': _address.text.trim(),
        'fee': _fee.text.trim().isEmpty ? '0' : _fee.text.trim(),
        'bank_name': _bankName.text.trim(),
        'bank_account_name': _bankAccountName.text.trim(),
        'bank_account_number': _bankAccountNumber.text.trim(),
        'bank_ifsc': _bankIfsc.text.trim().toUpperCase(),
        'bank_branch': _bankBranch.text.trim(),
      };
      final files = <String, File>{};
      if (_avatar != null) files['avatar'] = _avatar!;
      if (_panDoc != null) files['pan_document'] = _panDoc!;
      if (_aadhaarFront != null) files['aadhaar_front'] = _aadhaarFront!;
      if (_aadhaarBack != null) files['aadhaar_back'] = _aadhaarBack!;
      if (_aadhaarE != null) files['aadhaar_eaadhaar'] = _aadhaarE!;
      if (_certificate != null) files['certificate'] = _certificate!;
      if (_nmcCert != null) files['nmc_certificate'] = _nmcCert!;
      if (_smcCert != null) files['smc_certificate'] = _smcCert!;

      if (files.isEmpty) {
        await auth.pb.update('users', auth.user!.id, fields);
      } else {
        await auth.pb.updateWithFiles('users', auth.user!.id, fields, files);
      }
      await auth.refreshUser();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Profile saved successfully')),
        );
        setState(() {
          _avatar = _panDoc = _aadhaarFront = _aadhaarBack = _aadhaarE = _certificate = _nmcCert = _smcCert = null;
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not save: $e'), backgroundColor: AppTheme.destructive),
        );
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthState>();
    final u = auth.user!;
    final pb = auth.pb;
    final avatarUrl = u.avatarUrl(pb);

    return Form(
      key: _formKey,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Header card
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 32,
                    backgroundColor: AppTheme.primary,
                    backgroundImage: _avatar != null
                        ? FileImage(_avatar!)
                        : (avatarUrl.isNotEmpty ? NetworkImage(avatarUrl) as ImageProvider : null),
                    child: (_avatar == null && avatarUrl.isEmpty)
                        ? Text((u.name.isEmpty ? 'P' : u.name[0]).toUpperCase(),
                            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: Colors.white))
                        : null,
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(u.name.isEmpty ? 'Provider' : u.name,
                            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppTheme.charcoal)),
                        const SizedBox(height: 2),
                        Text(kRoleLabels[u.role] ?? u.role,
                            style: const TextStyle(fontSize: 12, color: AppTheme.muted)),
                        const SizedBox(height: 2),
                        Text('ID ${formatUniqueId(u.uniqueId)}',
                            style: const TextStyle(fontSize: 11, fontFamily: 'monospace', color: AppTheme.muted)),
                        const SizedBox(height: 6),
                        Wrap(
                          spacing: 6,
                          runSpacing: 6,
                          children: [
                            StatusBadge(status: u.kycVerified ? 'cleared' : 'pending_review'),
                            if (u.isAvailable)
                              const StatusBadge(status: 'confirmed'),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          TextButton.icon(
            onPressed: () async => setState(() => _avatar = await _pick(ImageSource.gallery)),
            icon: const Icon(Icons.photo_camera_outlined, size: 18),
            label: const Text('Change photo'),
          ),

          // KYC banner
          if (!u.kycVerified) ...[
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: const Color(0xFFFFFBEB),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFFFCD34D)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Profile not verified yet',
                      style: TextStyle(fontWeight: FontWeight.w700, color: Color(0xFF92400E))),
                  const SizedBox(height: 4),
                  Text(
                    u.kycResubmitReason.isNotEmpty
                        ? 'Issue to correct: ${u.kycResubmitReason}'
                        : 'Upload your KYC & professional documents below. Verified appears only after admin/team checks them.',
                    style: const TextStyle(fontSize: 12.5, color: Color(0xFF92400E)),
                  ),
                ],
              ),
            ),
          ],

          const SizedBox(height: 16),
          _sectionTitle('Personal details'),
          _field(_name, 'Full name', required: true),
          _field(_phone, 'Mobile', keyboardType: TextInputType.phone),
          if (u.isDoctor) ...[
            _field(_department, 'Department'),
            _field(_specialization, 'Specialization'),
            _field(_experience, 'Experience (years)', keyboardType: TextInputType.number),
            _field(_workplace, 'Present hospital / workplace'),
          ] else ...[
            _field(_specialization, 'Specialization / focus'),
            _field(_experience, 'Experience (years)', keyboardType: TextInputType.number),
            _field(_workplace, 'Present workplace / network'),
          ],
          _field(_address, 'Address'),
          Row(
            children: [
              Expanded(child: _field(_city, 'City')),
              const SizedBox(width: 10),
              Expanded(child: _field(_state, 'State')),
            ],
          ),
          _field(_pincode, 'Pincode', keyboardType: TextInputType.number),
          if (u.isDoctor) _field(_fee, 'Consultation fee (₹)', keyboardType: TextInputType.number),

          const SizedBox(height: 16),
          _sectionTitle('Bank details for settlement'),
          _field(_bankAccountName, 'Account holder name'),
          _field(_bankAccountNumber, 'Account number', keyboardType: TextInputType.number),
          _field(_bankIfsc, 'IFSC code'),
          _field(_bankName, 'Bank name'),
          _field(_bankBranch, 'Branch address'),

          const SizedBox(height: 16),
          _sectionTitle('KYC & professional documents'),
          const Padding(
            padding: EdgeInsets.only(bottom: 8),
            child: Text(
              'Private. Only you and authorized admins can view these files.',
              style: TextStyle(fontSize: 12, color: AppTheme.muted),
            ),
          ),
          _docPicker('PAN document', _panDoc, u.panDocumentFileUrl(pb), (f) => setState(() => _panDoc = f)),
          _docPicker('Aadhaar front side', _aadhaarFront, u.aadhaarFrontUrl(pb), (f) => setState(() => _aadhaarFront = f)),
          _docPicker('Aadhaar back side', _aadhaarBack, u.aadhaarBackUrl(pb), (f) => setState(() => _aadhaarBack = f)),
          _docPicker('e-Aadhaar (PDF)', _aadhaarE, u.aadhaarEUrl(pb), (f) => setState(() => _aadhaarE = f)),
          _docPicker('Diploma / degree certificate', _certificate, u.certificateUrl(pb), (f) => setState(() => _certificate = f)),
          if (u.isDoctor) ...[
            _docPicker('NMC registration certificate', _nmcCert, u.nmcCertUrl(pb), (f) => setState(() => _nmcCert = f)),
            _docPicker('SMC registration certificate', _smcCert, u.smcCertUrl(pb), (f) => setState(() => _smcCert = f)),
          ],

          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            height: 52,
            child: ElevatedButton(
              onPressed: _saving ? null : _save,
              child: _saving
                  ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5, valueColor: AlwaysStoppedAnimation(Colors.white)))
                  : const Text('Save changes'),
            ),
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  Widget _sectionTitle(String text) {
    return Padding(
      padding: const EdgeInsets.only(top: 8, bottom: 10),
      child: Text(text,
          style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppTheme.charcoal)),
    );
  }

  Widget _field(TextEditingController c, String label, {bool required = false, TextInputType? keyboardType}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextFormField(
        controller: c,
        keyboardType: keyboardType,
        decoration: InputDecoration(labelText: label),
        validator: required ? (v) => (v ?? '').trim().isEmpty ? 'Required' : null : null,
      ),
    );
  }

  Widget _docPicker(String label, File? picked, String? existingUrl, ValueChanged<File?> onPick) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppTheme.charcoal)),
                if (picked != null)
                  Text('Selected: ${picked.path.split('/').last}',
                      style: const TextStyle(fontSize: 11, color: AppTheme.emerald))
                else if (existingUrl != null && existingUrl.isNotEmpty)
                  GestureDetector(
                    onTap: () => _launch(existingUrl),
                    child: const Text('View current →',
                        style: TextStyle(fontSize: 11, color: AppTheme.primary, decoration: TextDecoration.underline)),
                  ),
              ],
            ),
          ),
          OutlinedButton.icon(
            icon: const Icon(Icons.upload_outlined, size: 16),
            label: const Text('Upload'),
            onPressed: () async => onPick(await _pick(ImageSource.gallery)),
          ),
        ],
      ),
    );
  }

  Future<void> _launch(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }
}

// Helper extension to expose file URLs from AppUser for KYC docs.
extension AppUserFileUrls on AppUser {
  String? panDocumentFileUrl(dynamic pb) =>
      (raw['pan_document'] as String?)?.isNotEmpty == true
          ? pb.fileUrl('users', id, raw['pan_document'] as String)
          : null;
  String? aadhaarFrontUrl(dynamic pb) =>
      (raw['aadhaar_front'] as String?)?.isNotEmpty == true
          ? pb.fileUrl('users', id, raw['aadhaar_front'] as String)
          : null;
  String? aadhaarBackUrl(dynamic pb) =>
      (raw['aadhaar_back'] as String?)?.isNotEmpty == true
          ? pb.fileUrl('users', id, raw['aadhaar_back'] as String)
          : null;
  String? aadhaarEUrl(dynamic pb) =>
      (raw['aadhaar_eaadhaar'] as String?)?.isNotEmpty == true
          ? pb.fileUrl('users', id, raw['aadhaar_eaadhaar'] as String)
          : null;
  String? certificateUrl(dynamic pb) =>
      (raw['certificate'] as String?)?.isNotEmpty == true
          ? pb.fileUrl('users', id, raw['certificate'] as String)
          : null;
  String? nmcCertUrl(dynamic pb) =>
      (raw['nmc_certificate'] as String?)?.isNotEmpty == true
          ? pb.fileUrl('users', id, raw['nmc_certificate'] as String)
          : null;
  String? smcCertUrl(dynamic pb) =>
      (raw['smc_certificate'] as String?)?.isNotEmpty == true
          ? pb.fileUrl('users', id, raw['smc_certificate'] as String)
          : null;
}
