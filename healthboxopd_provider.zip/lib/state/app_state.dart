import 'dart:async';
import 'package:flutter/foundation.dart';

import '../models/booking.dart';
import '../services/pocketbase_client.dart';
import 'auth_state.dart';

/// Holds the provider's bookings/assignments and settlements, with periodic
/// polling refresh (mobile-safe substitute for realtime subscriptions).
class AppState extends ChangeNotifier {
  AppState();

  List<Booking> _bookings = [];
  List<Settlement> _settlements = [];
  bool _loading = false;
  String? _error;
  Timer? _poll;

  List<Booking> get bookings => _bookings;
  List<Settlement> get settlements => _settlements;
  bool get loading => _loading;
  String? get error => _error;

  List<Booking> get active =>
      _bookings.where((b) => b.isActive).toList();
  List<Booking> get past =>
      _bookings.where((b) => b.isPast).toList();

  List<Booking> todays() {
    final today = DateTime.now().toIso8601String().substring(0, 10);
    return active.where((b) => b.bookingDate == today).toList();
  }

  Future<void> load(AuthState auth, {bool silent = false}) async {
    if (!auth.isAuthed) return;
    if (!silent) {
      _loading = true;
      _error = null;
      notifyListeners();
    }
    final pb = auth.pb;
    final userId = auth.user!.id;
    try {
      final results = await Future.wait([
        pb.getFullList('bookings',
            filter: 'provider = "$userId"',
            sort: '-created',
            expand: 'patient,family_patient,center'),
        pb
            .getFullList('settlements',
                filter: 'doctor = "$userId"',
                sort: '-created',
                expand: 'booking')
            .catchError((_) => <Map<String, dynamic>>[]),
      ]);
      _bookings = (results[0] as List<Map<String, dynamic>>)
          .map(Booking.fromRecord)
          .toList();
      _settlements = (results[1] as List<Map<String, dynamic>>)
          .map(Settlement.fromRecord)
          .toList();
      _error = null;
    } on PbException catch (e) {
      _error = e.message;
    } catch (_) {
      _error = 'Could not load data. Pull to retry.';
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  /// Start a background poll every 20s for new/updated bookings.
  void startPolling(AuthState auth) {
    _poll?.cancel();
    _poll = Timer.periodic(const Duration(seconds: 20), (_) => load(auth, silent: true));
  }

  void stopPolling() {
    _poll?.cancel();
    _poll = null;
  }

  /// Update a single booking in local state after a status change.
  void upsertBooking(Booking updated) {
    final idx = _bookings.indexWhere((b) => b.id == updated.id);
    if (idx >= 0) {
      _bookings[idx] = updated;
    } else {
      _bookings.insert(0, updated);
    }
    notifyListeners();
  }

  @override
  void dispose() {
    stopPolling();
    super.dispose();
  }
}
