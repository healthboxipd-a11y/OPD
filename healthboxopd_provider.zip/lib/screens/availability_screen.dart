import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../config.dart';
import '../state/auth_state.dart';
import '../utils/theme.dart';
import '../widgets/common.dart';

/// Weekly availability editor mirroring the website AvailabilityEditor.
class AvailabilityScreen extends StatefulWidget {
  const AvailabilityScreen({super.key});

  @override
  State<AvailabilityScreen> createState() => _AvailabilityScreenState();
}

class _AvailabilityScreenState extends State<AvailabilityScreen> {
  Map<String, List<String>> _avail = {};
  bool _saving = false;
  bool _loaded = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_loaded) {
      final user = context.read<AuthState>().user;
      _avail = _normalize(user?.availability);
      _loaded = true;
    }
  }

  Map<String, List<String>> _normalize(Map<String, dynamic>? raw) {
    final out = <String, List<String>>{};
    if (raw == null) return out;
    for (final day in kWeekDays) {
      final v = raw[day['id']];
      if (v is List) out[day['id']!] = v.map((e) => e.toString()).toList();
    }
    return out;
  }

  void _toggle(String day, String slot) {
    setState(() {
      final cur = List<String>.from(_avail[day] ?? []);
      if (cur.contains(slot)) {
        cur.remove(slot);
      } else {
        cur.add(slot);
        cur.sort();
      }
      _avail[day] = cur;
    });
  }

  Future<void> _save() async {
    final auth = context.read<AuthState>();
    setState(() => _saving = true);
    try {
      await auth.pb.update('users', auth.user!.id, {'availability': _avail});
      await auth.refreshUser();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Availability schedule saved')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not save: $e'), backgroundColor: AppTheme.destructive),
        );
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
          'Availability & Schedule',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppTheme.charcoal),
        ),
        const SizedBox(height: 6),
        const Text(
          'Set the time windows you accept visits. Patients can only book you for the slots you enable here.',
          style: TextStyle(fontSize: 13, color: AppTheme.muted),
        ),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: kWeekDays.map((day) {
                final id = day['id']!;
                final label = day['label']!;
                final selected = _avail[id] ?? [];
                return ExpansionTile(
                  title: Text(label, style: const TextStyle(fontWeight: FontWeight.w600)),
                  subtitle: Text(
                    selected.isEmpty ? 'Unavailable' : '${selected.length} slot(s)',
                    style: TextStyle(fontSize: 12, color: selected.isEmpty ? AppTheme.muted : AppTheme.emerald),
                  ),
                  tilePadding: EdgeInsets.zero,
                  children: [
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: kTimeSlots.map((slot) {
                        final on = selected.contains(slot);
                        return FilterChip(
                          label: Text(slot),
                          selected: on,
                          onSelected: (_) => _toggle(id, slot),
                          selectedColor: AppTheme.primary.withOpacity(0.15),
                          checkmarkColor: AppTheme.primary,
                        );
                      }).toList(),
                    ),
                  ],
                );
              }).toList(),
            ),
          ),
        ),
        const SizedBox(height: 16),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: _saving ? null : _save,
            child: _saving
                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2.5, valueColor: AlwaysStoppedAnimation(Colors.white)))
                : const Text('Save availability'),
          ),
        ),
      ],
    );
  }
}
