import '../services/pocketbase_client.dart';

/// A booking / appointment / assignment (PocketBase `bookings` collection).
class Booking {
  Booking({
    required this.id,
    this.appointmentId = '',
    this.service = '',
    this.careServiceLabel = '',
    this.status = '',
    this.paymentStatus = '',
    this.bookingDate = '',
    this.timeSlot = '',
    this.duration = '',
    this.customDays,
    this.amount = 0,
    this.visitCharge = 0,
    this.notes = '',
    this.address = '',
    this.patient,
    this.patientId = '',
    this.patientName = '',
    this.patientPhone = '',
    this.patientUniqueId = '',
    this.centerName = '',
    this.prescriptionText = '',
    this.vitals,
    this.reportFiles = const [],
    this.isFollowup = false,
    this.completionVerified = false,
    this.completionOtpExpires = '',
    this.created = '',
    this.updated = '',
    this.expand,
    this.raw,
  });

  final String id;
  final String appointmentId;
  final String service;
  final String careServiceLabel;
  final String status;
  final String paymentStatus;
  final String bookingDate;
  final String timeSlot;
  final String duration;
  final num? customDays;
  final num amount;
  final num visitCharge;
  final String notes;
  final String address;
  final Map<String, dynamic>? patient;
  final String patientId;
  final String patientName;
  final String patientPhone;
  final String patientUniqueId;
  final String centerName;
  final String prescriptionText;
  final Map<String, dynamic>? vitals;
  final List<dynamic> reportFiles;
  final bool isFollowup;
  final bool completionVerified;
  final String completionOtpExpires;
  final String created;
  final String updated;
  final Map<String, dynamic>? expand;
  final Map<String, dynamic> raw;

  factory Booking.fromRecord(Map<String, dynamic> r) {
    final expand = r['expand'] is Map ? r['expand'] as Map<String, dynamic> : <String, dynamic>{};
    final patient = expand['patient'] is Map ? expand['patient'] as Map<String, dynamic> : null;
    final center = expand['center'] is Map ? expand['center'] as Map<String, dynamic> : null;
    final files = r['report_files'];
    return Booking(
      id: r['id'] as String? ?? '',
      appointmentId: r['appointment_id'] as String? ?? '',
      service: r['service'] as String? ?? '',
      careServiceLabel: r['care_service_label'] as String? ?? '',
      status: r['status'] as String? ?? '',
      paymentStatus: r['payment_status'] as String? ?? '',
      bookingDate: r['booking_date'] as String? ?? '',
      timeSlot: r['time_slot'] as String? ?? '',
      duration: r['duration'] as String? ?? '',
      customDays: r['custom_days'] is num ? r['custom_days'] as num : null,
      amount: r['amount'] is num ? r['amount'] as num : 0,
      visitCharge: r['visit_charge'] is num ? r['visit_charge'] as num : 0,
      notes: r['notes'] as String? ?? '',
      address: r['address'] as String? ?? '',
      patient: patient,
      patientId: PocketBaseClient.relationId(r['patient']) ?? '',
      patientName: patient?['name'] as String? ?? '',
      patientPhone: patient?['phone'] as String? ?? '',
      patientUniqueId: patient?['unique_id'] as String? ?? '',
      centerName: center?['name'] as String? ?? (r['center_name'] as String? ?? ''),
      prescriptionText: r['prescription_text'] as String? ?? '',
      vitals: r['vitals'] is Map ? r['vitals'] as Map<String, dynamic> : null,
      reportFiles: files is List ? files : (files is String && files.isNotEmpty ? [files] : []),
      isFollowup: r['is_followup'] == true,
      completionVerified: r['completion_verified'] == true,
      completionOtpExpires: r['completion_otp_expires'] as String? ?? '',
      created: r['created'] as String? ?? '',
      updated: r['updated'] as String? ?? '',
      expand: expand,
      raw: r,
    );
  }

  bool get isActive => !['completed', 'cancelled'].contains(status);
  bool get isPast => ['completed', 'cancelled'].contains(status);
  bool get paymentPaid => paymentStatus == 'paid';
}

/// A settlement payout request (PocketBase `settlements` collection).
class Settlement {
  Settlement({
    required this.id,
    this.status = '',
    this.invoiceNo = '',
    this.gross = 0,
    this.eligible = 0,
    this.finalPayout,
    this.transferredOn = '',
    this.verifiedByName = '',
    this.deductions = const [],
    this.created = '',
    this.booking,
    this.raw,
  });

  final String id;
  final String status;
  final String invoiceNo;
  final num gross;
  final num eligible;
  final num? finalPayout;
  final String transferredOn;
  final String verifiedByName;
  final List<dynamic> deductions;
  final String created;
  final Map<String, dynamic>? booking;
  final Map<String, dynamic> raw;

  factory Settlement.fromRecord(Map<String, dynamic> r) {
    final expand = r['expand'] is Map ? r['expand'] as Map<String, dynamic> : <String, dynamic>{};
    final booking = expand['booking'] is Map ? expand['booking'] as Map<String, dynamic> : null;
    return Settlement(
      id: r['id'] as String? ?? '',
      status: r['status'] as String? ?? '',
      invoiceNo: r['invoice_no'] as String? ?? '',
      gross: r['gross_amount'] is num ? r['gross_amount'] as num : (r['amount'] is num ? r['amount'] as num : 0),
      eligible: r['eligible_payout'] is num ? r['eligible_payout'] as num : 0,
      finalPayout: r['final_payout'] is num ? r['final_payout'] as num : null,
      transferredOn: r['transferred_on'] as String? ?? '',
      verifiedByName: r['verified_by_name'] as String? ?? '',
      deductions: r['deductions'] is List ? r['deductions'] as List : [],
      created: r['created'] as String? ?? '',
      booking: booking,
      raw: r,
    );
  }

  bool get isSettled => status == 'settled' || status == 'paid';
}
