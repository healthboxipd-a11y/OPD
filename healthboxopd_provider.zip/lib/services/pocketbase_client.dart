import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

import '../config.dart';

/// A typed exception wrapping a PocketBase REST error response.
class PbException implements Exception {
  PbException(this.message, {this.status, this.data});
  final String message;
  final int? status;
  final Map<String, dynamic>? data;

  factory PbException.fromResponse(http.Response res) {
    String message = 'Request failed (${res.statusCode})';
    Map<String, dynamic>? data;
    try {
      final body = jsonDecode(res.body);
      if (body is Map<String, dynamic>) {
        data = body;
        final msg = body['message'];
        if (msg is String && msg.isNotEmpty) message = msg;
        final dataField = body['data'];
        if (dataField is Map<String, dynamic>) {
          // Surface the first field validation message.
          for (final entry in dataField.entries) {
            final v = entry.value;
            if (v is Map && v['message'] is String) {
              message = '${entry.key}: ${v['message']}';
              break;
            }
          }
        }
      }
    } catch (_) {
      if (res.body.isNotEmpty && res.body.length < 200) message = res.body;
    }
    return PbException(message, status: res.statusCode, data: data);
  }

  @override
  String toString() => message;
}

/// Thin REST wrapper around PocketBase. Mirrors the JS SDK calls used by the
/// website (auth, CRUD, file URLs, auth refresh).
class PocketBaseClient {
  PocketBaseClient();

  String get base => kPocketBaseUrl;
  String? _token;

  String? get token => _token;
  bool get isAuthed => _token != null && _token!.isNotEmpty;

  void setToken(String? token) => _token = token;
  void clearToken() => _token = null;

  Map<String, String> _headers({bool json = true, bool auth = true}) {
    final h = <String, String>{};
    if (json) h['Content-Type'] = 'application/json';
    if (auth && _token != null && _token!.isNotEmpty) {
      h['Authorization'] = 'Bearer $_token';
    }
    return h;
  }

  Uri _uri(String path, [Map<String, dynamic>? query]) {
    final url = Uri.parse('$base$path');
    if (query == null || query.isEmpty) return url;
    final q = Map<String, dynamic>.from(query);
    q.removeWhere((_, v) => v == null);
    return url.replace(queryParameters: q.map((k, v) => MapEntry(k, v.toString())));
  }

  // ---- Auth ----

  /// Authenticate with email OR mobile number + password. The backend hook
  /// resolves mobile numbers to the saved account email.
  Future<Map<String, dynamic>> authWithPassword(String identity, String password) async {
    final res = await http.post(
      _uri('/api/collections/users/auth-with-password'),
      headers: _headers(),
      body: jsonEncode({'identity': identity, 'password': password}),
    );
    if (res.statusCode != 200) {
      throw PbException.fromResponse(res);
    }
    final body = jsonDecode(res.body) as Map<String, dynamic>;
    _token = body['token'] as String?;
    return body;
  }

  Future<Map<String, dynamic>> authRefresh() async {
    final res = await http.post(
      _uri('/api/collections/users/auth-refresh'),
      headers: _headers(),
    );
    if (res.statusCode != 200) {
      throw PbException.fromResponse(res);
    }
    final body = jsonDecode(res.body) as Map<String, dynamic>;
    _token = body['token'] as String?;
    return body;
  }

  // ---- Records ----

  Future<List<Map<String, dynamic>>> getFullList(
    String collection, {
    String? filter,
    String? sort,
    String? expand,
    int perPage = 200,
  }) async {
    final res = await http.get(
      _uri('/api/collections/$collection/records', {
        'filter': filter,
        'sort': sort,
        'expand': expand,
        'page': 1,
        'perPage': perPage,
      }),
      headers: _headers(json: false),
    );
    if (res.statusCode != 200) throw PbException.fromResponse(res);
    final body = jsonDecode(res.body) as Map<String, dynamic>;
    final items = body['items'];
    return items is List
        ? items.map((e) => e as Map<String, dynamic>).toList()
        : <Map<String, dynamic>>[];
  }

  Future<Map<String, dynamic>> getOne(
    String collection,
    String id, {
    String? expand,
  }) async {
    final res = await http.get(
      _uri('/api/collections/$collection/records/$id', {'expand': expand}),
      headers: _headers(json: false),
    );
    if (res.statusCode != 200) throw PbException.fromResponse(res);
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> getFirstListItem(
    String collection,
    String filter, {
    String? expand,
  }) async {
    final list = await getFullList(collection, filter: filter, expand: expand, perPage: 1);
    if (list.isEmpty) throw PbException('No matching record', status: 404);
    return list.first;
  }

  Future<Map<String, dynamic>> create(
    String collection,
    Map<String, dynamic> body,
  ) async {
    final res = await http.post(
      _uri('/api/collections/$collection/records'),
      headers: _headers(),
      body: jsonEncode(body),
    );
    if (res.statusCode < 200 || res.statusCode >= 300) throw PbException.fromResponse(res);
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> update(
    String collection,
    String id,
    Map<String, dynamic> body,
  ) async {
    final res = await http.patch(
      _uri('/api/collections/$collection/records/$id'),
      headers: _headers(),
      body: jsonEncode(body),
    );
    if (res.statusCode < 200 || res.statusCode >= 300) throw PbException.fromResponse(res);
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  /// Update with multipart form-data (file uploads).
  Future<Map<String, dynamic>> updateWithFiles(
    String collection,
    String id,
    Map<String, String> fields,
    Map<String, File> files,
  ) async {
    final req = http.MultipartRequest(
      'PATCH',
      _uri('/api/collections/$collection/records/$id'),
    );
    req.headers.addAll(_headers(json: false));
    fields.forEach((k, v) => req.fields[k] = v);
    files.forEach((field, file) {
      req.files.add(http.MultipartFile.fromBytes(field, file.readAsBytesSync(),
          filename: file.path.split('/').last));
    });
    final streamed = await req.send();
    final res = await http.Response.fromStream(streamed);
    if (res.statusCode < 200 || res.statusCode >= 300) throw PbException.fromResponse(res);
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  Future<void> delete(String collection, String id) async {
    final res = await http.delete(
      _uri('/api/collections/$collection/records/$id'),
      headers: _headers(json: false),
    );
    if (res.statusCode < 200 || res.statusCode >= 300) throw PbException.fromResponse(res);
  }

  /// Build a file URL for a record file field.
  String fileUrl(String collectionName, String recordId, String filename, {String? thumb}) {
    final q = <String, dynamic>{};
    if (thumb != null && thumb.isNotEmpty) q['thumb'] = thumb;
    // Protected files need the token as a query param.
    if (_token != null && _token!.isNotEmpty) q['token'] = _token;
    return _uri('/api/files/$collectionName/$recordId/$filename', q).toString();
  }

  /// Convenience: resolve a relation id that may be a string or expanded object.
  static String? relationId(dynamic value) {
    if (value == null) return null;
    if (value is String) return value;
    if (value is Map) return value['id'] as String?;
    return null;
  }
}
