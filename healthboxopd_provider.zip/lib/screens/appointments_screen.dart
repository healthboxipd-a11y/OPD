import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/booking.dart';
import '../state/app_state.dart';
import '../state/auth_state.dart';
import '../utils/theme.dart';
import '../widgets/common.dart';
import '../widgets/booking_tile.dart';
import 'appointment_detail_screen.dart';

class AppointmentsScreen extends StatelessWidget {
  const AppointmentsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final auth = context.watch<AuthState>();
    final isDoctor = auth.user?.isDoctor ?? false;
    final title = isDoctor ? 'Appointments' : 'Assignments';

    if (app.loading && app.bookings.isEmpty) return const LoadingView();

    return DefaultTabController(
      length: 2,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                title,
                style: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                  color: AppTheme.charcoal,
                ),
              ),
            ),
          ),
          const TabBar(
            tabs: [Tab(text: 'Active'), Tab(text: 'Past')],
            labelColor: AppTheme.primary,
            unselectedLabelColor: AppTheme.muted,
          ),
          Expanded(
            child: TabBarView(
              children: [
                _List(bookings: app.active, empty: 'No active $title'.toLowerCase()),
                _List(bookings: app.past, empty: 'No past $title'.toLowerCase()),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _List extends StatelessWidget {
  const _List({required this.bookings, required this.empty});
  final List<Booking> bookings;
  final String empty;

  @override
  Widget build(BuildContext context) {
    if (bookings.isEmpty) {
      return EmptyState(message: empty, icon: Icons.event_busy);
    }
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        for (final b in bookings)
          BookingTile(
            booking: b,
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => AppointmentDetailScreen(booking: b)),
            ),
          ),
      ],
    );
  }
}
