import 'package:flutter/material.dart';

import '../utils/theme.dart';
import '../utils/formatters.dart';

/// Colored status pill mirroring the website StatusBadge.
class StatusBadge extends StatelessWidget {
  const StatusBadge({super.key, required this.status});
  final String? status;

  @override
  Widget build(BuildContext context) {
    final s = (status ?? '').trim();
    if (s.isEmpty) return const SizedBox.shrink();
    final spec = _specs[s] ?? _Spec(AppTheme.muted, Colors.white);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: spec.bg,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: spec.bg.withOpacity(0.4)),
      ),
      child: Text(
        statusLabel(s),
        style: TextStyle(
          color: spec.fg,
          fontSize: 11,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}

class _Spec {
  const _Spec(this.bg, this.fg);
  final Color bg;
  final Color fg;
}

final Map<String, _Spec> _specs = {
  'pending': _Spec(Color(0xFFFEF3C7), Color(0xFF92400E)),
  'confirmed': _Spec(Color(0xFFDBEAFE), Color(0xFF1E40AF)),
  'assigned': _Spec(Color(0xFFDBEAFE), Color(0xFF1E40AF)),
  'in_progress': _Spec(Color(0xFFFFE4E6), Color(0xFFBE123C)),
  'completed': _Spec(Color(0xFFD1FAE5), Color(0xFF065F46)),
  'cancelled': _Spec(Color(0xFFFEE2E2), Color(0xFF991B1B)),
  'paid': _Spec(Color(0xFFD1FAE5), Color(0xFF065F46)),
  'unpaid': _Spec(Color(0xFFFEF3C7), Color(0xFF92400E)),
  'refunded': _Spec(Color(0xFFE0E7FF), Color(0xFF3730A3)),
  'settled': _Spec(Color(0xFFD1FAE5), Color(0xFF065F46)),
  'requested': _Spec(Color(0xFFFEF3C7), Color(0xFF92400E)),
  'processing': _Spec(Color(0xFFFEF3C7), Color(0xFF92400E)),
  'rejected': _Spec(Color(0xFFFEE2E2), Color(0xFF991B1B)),
  'cleared': _Spec(Color(0xFFD1FAE5), Color(0xFF065F46)),
  'pending_review': _Spec(Color(0xFFFEF3C7), Color(0xFF92400E)),
  'resubmit': _Spec(Color(0xFFFEE2E2), Color(0xFF991B1B)),
};
