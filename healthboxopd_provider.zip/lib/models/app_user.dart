import '../services/pocketbase_client.dart';

/// A user account (PocketBase `users` auth collection).
class AppUser {
  AppUser({
    required this.id,
    required this.email,
    this.name = '',
    this.phone = '',
    this.role = '',
    this.uniqueId = '',
    this.avatar = '',
    this.department = '',
    this.specialization = '',
    this.experience,
    this.workplace = '',
    this.city = '',
    this.state = '',
    this.pincode = '',
    this.address = '',
    this.fee,
    this.isVerified = false,
    this.isAvailable = true,
    this.status = '',
    this.availability,
    this.offeredServices,
    this.bankAccountName = '',
    this.bankAccountNumber = '',
    this.bankIfsc = '',
    this.bankName = '',
    this.bankBranch = '',
    this.panNo = '',
    this.panVerified = false,
    this.nmcRegistration = '',
    this.smcRegistration = '',
    this.smcState = '',
    this.kycReviewStatus = '',
    this.kycResubmitReason = '',
    this.kycVerifiedAt = '',
    this.medicalSystem = '',
    this.languages,
    this.qualifications,
    this.advertiseProfile = true,
    this.collectionId = '',
    this.raw,
  });

  final String id;
  final String email;
  final String name;
  final String phone;
  final String role;
  final String uniqueId;
  final String avatar;
  final String department;
  final String specialization;
  final num? experience;
  final String workplace;
  final String city;
  final String state;
  final String pincode;
  final String address;
  final num? fee;
  final bool isVerified;
  final bool isAvailable;
  final String status;
  final Map<String, dynamic>? availability;
  final List<dynamic>? offeredServices;
  final String bankAccountName;
  final String bankAccountNumber;
  final String bankIfsc;
  final String bankName;
  final String bankBranch;
  final String panNo;
  final bool panVerified;
  final String nmcRegistration;
  final String smcRegistration;
  final String smcState;
  final String kycReviewStatus;
  final String kycResubmitReason;
  final String kycVerifiedAt;
  final String medicalSystem;
  final List<dynamic>? languages;
  final List<dynamic>? qualifications;
  final bool advertiseProfile;
  final String collectionId;
  final Map<String, dynamic> raw;

  factory AppUser.fromRecord(Map<String, dynamic> r) {
    return AppUser(
      id: r['id'] as String? ?? '',
      email: r['email'] as String? ?? '',
      name: r['name'] as String? ?? '',
      phone: r['phone'] as String? ?? '',
      role: r['role'] as String? ?? '',
      uniqueId: r['unique_id'] as String? ?? '',
      avatar: r['avatar'] as String? ?? '',
      department: r['department'] as String? ?? '',
      specialization: r['specialization'] as String? ?? '',
      experience: r['experience'] is num ? r['experience'] as num : null,
      workplace: r['workplace'] as String? ?? '',
      city: r['city'] as String? ?? '',
      state: r['state'] as String? ?? '',
      pincode: r['pincode'] as String? ?? '',
      address: r['address'] as String? ?? '',
      fee: r['fee'] is num ? r['fee'] as num : null,
      isVerified: r['is_verified'] == true,
      isAvailable: r['is_available'] != false,
      status: r['status'] as String? ?? '',
      availability: r['availability'] is Map ? r['availability'] as Map<String, dynamic> : null,
      offeredServices: r['offered_services'] is List ? r['offered_services'] as List : null,
      bankAccountName: r['bank_account_name'] as String? ?? '',
      bankAccountNumber: r['bank_account_number'] as String? ?? '',
      bankIfsc: r['bank_ifsc'] as String? ?? '',
      bankName: r['bank_name'] as String? ?? '',
      bankBranch: r['bank_branch'] as String? ?? '',
      panNo: r['pan_no'] as String? ?? '',
      panVerified: r['pan_verified'] == true,
      nmcRegistration: (r['nmc_registration'] ?? r['mci_registration'] ?? r['registration_no'] ?? '') as String,
      smcRegistration: r['smc_registration'] as String? ?? '',
      smcState: r['smc_state'] as String? ?? '',
      kycReviewStatus: r['kyc_review_status'] as String? ?? '',
      kycResubmitReason: r['kyc_resubmit_reason'] as String? ?? '',
      kycVerifiedAt: r['kyc_verified_at'] as String? ?? '',
      medicalSystem: r['medical_system'] as String? ?? '',
      languages: r['languages'] is List ? r['languages'] as List : null,
      qualifications: r['qualifications'] is List ? r['qualifications'] as List : null,
      advertiseProfile: r['advertise_profile'] != false,
      collectionId: r['collectionId'] as String? ?? '',
      raw: r,
    );
  }

  bool get isDoctor => role == 'doctor';
  bool get isCareProvider =>
      ['nursing', 'physio', 'attendant', 'dietitian', 'psychologist'].contains(role);

  /// KYC documents checked & verified (separate from profile approval).
  bool get kycVerified => kycReviewStatus == 'cleared';

  /// Avatar file URL (protected).
  String avatarUrl(PocketBaseClient pb) =>
      avatar.isEmpty ? '' : pb.fileUrl('users', id, avatar, thumb: '200x200');
}
