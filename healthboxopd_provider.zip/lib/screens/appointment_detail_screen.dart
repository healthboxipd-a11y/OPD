import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models/booking.dart';
import '../state/app_state.dart';
import '../state/auth_state.dart';
import '../utils/formatters.dart';
import '../utils/theme.dart';
import '../widgets/status_badge.dart';

class AppointmentDetailScreen extends StatefulWidget {
  const AppointmentDetailScreen({super.key, required this.booking});
  final Booking booking;

  @override
  State<AppointmentDetailScreen> createState() => _AppointmentDetailScreenState();
}

class _AppointmentDetailScreenState extends State<AppointmentDetailScreen> {
  bool _busy = false;
  final _otp = TextEditingController();

  @override
  void dispose() {
    _otp.dispose();
    super.dispose();
  }

  Future<void> _setStatus(String status) async {
    final auth = context.read<AuthState>();
    final app = context.read<AppState>();
    setState(() => _busy = true);
    try {
      final updated = await auth.pb.update('bookings', widget.booking.id, {'status': status});
      final b = Booking.fromRecord(updated);
      app.upsertBooking(b);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Marked as ${statusLabel(status)}')),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not update: $e'), backgroundColor: AppTheme.destructive),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _sendOtp() async {
    final auth = context.read<AuthState>();
    setState(() => _busy = true);
    try {
      final code = (100000 + DateTime.now().millisecond * 997 % 900000).toString();
      final expires = DateTime.now().add(const Duration(minutes: 15)).toIso8601String();
      await auth.pb.update('bookings', widget.booking.id, {
        'completion_otp': code,
        'completion_otp_expires': expires,
        'completion_verified': false,
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('OTP sent to the customer\'s registered email. Ask them for the 6-digit code.')),
        );
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not send OTP.'), backgroundColor: AppTheme.destructive),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _verifyOtp() async {
    final auth = context.read<AuthState>();
    final app = context.read<AppState>();
    if (!RegExp(r'^\d{6}$').hasMatch(_otp.text.trim())) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enter the 6-digit OTP from the customer.')),
      );
      return;
    }
    setState(() => _busy = true);
    try {
      final updated = await auth.pb.update('bookings', widget.booking.id, {
        'completion_verify_code': _otp.text.trim(),
      });
      final b = Booking.fromRecord(updated);
      app.upsertBooking(b);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Customer verified. Service marked completed.')),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not verify: $e'), backgroundColor: AppTheme.destructive),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final b = widget.booking;
    final auth = context.watch<AuthState>();
    final isDoctor = auth.user?.isDoctor ?? false;
    final canAct = b.isActive;
    final awaitingPay = !b.paymentPaid && ['pending', 'assigned'].contains(b.status);

    return Scaffold(
      appBar: AppBar(title: const Text('Details')),
      body: _busy
          ? const LoadingView(message: 'Updating…')
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Wrap(
                          spacing: 8,
                          runSpacing: 6,
                          crossAxisAlignment: WrapCrossAlignment.center,
                          children: [
                            Text(serviceName(b.service),
                                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppTheme.charcoal)),
                            if (b.appointmentId.isNotEmpty)
                              Text('#${formatUniqueId(b.appointmentId)}',
                                  style: const TextStyle(fontFamily: 'monospace', fontSize: 12, fontWeight: FontWeight.w600, color: AppTheme.primary)),
                            StatusBadge(status: b.status),
                            StatusBadge(status: b.paymentStatus),
                          ],
                        ),
                        const SizedBox(height: 16),
                        _row('Patient', b.patientName.isNotEmpty ? b.patientName : '—'),
                        if (b.patientPhone.isNotEmpty)
                          _row('Phone', '+91 ${b.patientPhone}'),
                        if (b.patientUniqueId.isNotEmpty)
                          _row('Patient ID', formatUniqueId(b.patientUniqueId)),
                        _row('Schedule', '${b.bookingDate.isEmpty ? "—" : b.bookingDate} · ${b.timeSlot.isEmpty ? "—" : b.timeSlot}'),
                        if (b.centerName.isNotEmpty) _row('Center', b.centerName),
                        _row('Amount', formatINR(b.amount)),
                        if (b.visitCharge > 0)
                          _row('Home visit charge', formatINR(b.visitCharge)),
                        if (b.address.isNotEmpty) _row('Address', b.address),
                      ],
                    ),
                  ),
                ),
                if (b.notes.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Patient notes',
                              style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppTheme.muted, letterSpacing: 0.5)),
                          const SizedBox(height: 6),
                          Text(b.notes, style: const TextStyle(fontSize: 14)),
                        ],
                      ),
                    ),
                  ),
                ],
                if (b.vitals != null && b.vitals!.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Vitals (center team)',
                              style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: Color(0xFF115E59), letterSpacing: 0.5)),
                          const SizedBox(height: 8),
                          ...b.vitals!.entries.map((e) => Padding(
                                padding: const EdgeInsets.only(bottom: 4),
                                child: Text('${e.key}: ${e.value}',
                                    style: const TextStyle(fontSize: 13)),
                              )),
                        ],
                      ),
                    ),
                  ),
                ],
                if (b.prescriptionText.isNotEmpty && isDoctor) ...[
                  const SizedBox(height: 12),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Prescription',
                              style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppTheme.muted, letterSpacing: 0.5)),
                          const SizedBox(height: 6),
                          Text(b.prescriptionText, style: const TextStyle(fontSize: 13, fontFamily: 'monospace')),
                        ],
                      ),
                    ),
                  ),
                ],
                if (awaitingPay) ...[
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFFBEB),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: const Color(0xFFFCD34D)),
                    ),
                    child: const Text(
                      'Payment is not confirmed yet. You cannot confirm or cancel this appointment until payment is verified.',
                      style: TextStyle(fontSize: 12.5, color: Color(0xFF92400E)),
                    ),
                  ),
                ],
                if (canAct && !awaitingPay) ...[
                  const SizedBox(height: 16),
                  if (['pending', 'assigned'].contains(b.status)) ...[
                    Row(
                      children: [
                        Expanded(child: ElevatedButton(onPressed: () => _setStatus('confirmed'), child: const Text('Accept'))),
                        const SizedBox(width: 10),
                        Expanded(child: OutlinedButton(onPressed: () => _setStatus('cancelled'), child: const Text('Cancel'))),
                      ],
                    ),
                  ],
                  if (!isDoctor && b.status == 'in_progress' && !b.completionVerified) ...[
                    const SizedBox(height: 16),
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('Customer OTP verification',
                                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: Color(0xFF065F46))),
                            const SizedBox(height: 6),
                            const Text(
                              'After delivering the service, send a one-time code to the customer. Enter the code they share to verify and complete the visit.',
                              style: TextStyle(fontSize: 12, color: AppTheme.muted),
                            ),
                            const SizedBox(height: 12),
                            Row(
                              children: [
                                Expanded(
                                  child: OutlinedButton.icon(
                                    icon: const Icon(Icons.send_outlined, size: 16),
                                    label: const Text('Send OTP'),
                                    onPressed: _sendOtp,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 10),
                            TextField(
                              controller: _otp,
                              keyboardType: TextInputType.number,
                              maxLength: 6,
                              decoration: const InputDecoration(labelText: 'Customer OTP', isDense: true),
                            ),
                            const SizedBox(height: 10),
                            SizedBox(
                              width: double.infinity,
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(backgroundColor: AppTheme.emerald),
                                onPressed: _verifyOtp,
                                child: const Text('Verify & complete'),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                  if (!isDoctor && ['assigned', 'confirmed', 'pending'].contains(b.status))
                    Padding(
                      padding: const EdgeInsets.only(top: 12),
                      child: SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          icon: const Icon(Icons.play_arrow, size: 18),
                          label: const Text('Start visit'),
                          onPressed: () => _setStatus('in_progress'),
                        ),
                      ),
                    ),
                  if (isDoctor && b.status == 'confirmed')
                    Padding(
                      padding: const EdgeInsets.only(top: 12),
                      child: SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          icon: const Icon(Icons.video_call_outlined, size: 18),
                          label: const Text('Mark completed'),
                          onPressed: () => _setStatus('completed'),
                        ),
                      ),
                    ),
                ],
                if (b.patientPhone.isNotEmpty) ...[
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          icon: const Icon(Icons.phone_outlined),
                          label: const Text('Call patient'),
                          onPressed: () => launchUrl(Uri.parse('tel:+91${b.patientPhone}')),
                        ),
                      ),
                    ],
                  ),
                ],
                const SizedBox(height: 24),
              ],
            ),
    );
  }

  Widget _row(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 110,
            child: Text(label.toUpperCase(),
                style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: AppTheme.muted, letterSpacing: 0.4)),
          ),
          Expanded(child: Text(value, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500))),
        ],
      ),
    );
  }
}
