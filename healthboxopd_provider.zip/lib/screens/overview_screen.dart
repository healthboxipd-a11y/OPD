import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/app_user.dart';
import '../models/booking.dart';
import '../state/app_state.dart';
import '../state/auth_state.dart';
import '../utils/formatters.dart';
import '../utils/theme.dart';
import '../widgets/common.dart';
import '../widgets/booking_tile.dart';
import 'appointment_detail_screen.dart';

class OverviewScreen extends StatelessWidget {
  const OverviewScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final auth = context.watch<AuthState>();
    final user = auth.user;
    if (user == null) return const SizedBox.shrink();

    if (app.loading && app.bookings.isEmpty) {
      return const LoadingView();
    }
    if (app.error != null && app.bookings.isEmpty) {
      return EmptyState(message: app.error!, icon: Icons.cloud_off_outlined);
    }

    final active = app.active;
    final todays = app.todays();
    final completed = app.past.where((b) => b.status == 'completed').toList();
    final completedPaid = completed.where((b) => b.paymentPaid).toList();
    final earnings = completedPaid.fold<num>(0, (s, b) => s + (b.amount ?? 0));

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        if (!user.kycVerified) _kycBanner(context, user),
        const SizedBox(height: 4),
        const Text(
          'At a glance',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppTheme.charcoal),
        ),
        const SizedBox(height: 12),
        GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: 2,
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: 1.4,
          children: [
            StatCard(label: 'Today', value: '${todays.length}', icon: Icons.calendar_today, bar: AppTheme.primary, tint: const Color(0xFFE0EBFF)),
            StatCard(label: 'Active', value: '${active.length}', icon: Icons.bolt, bar: AppTheme.amber, tint: const Color(0xFFFEF3C7)),
            StatCard(label: 'Completed', value: '${completed.length}', icon: Icons.check_circle_outline, bar: AppTheme.emerald, tint: const Color(0xFFD1FAE5)),
            StatCard(label: 'Earnings (paid)', value: formatINR(earnings), icon: Icons.account_balance_wallet, bar: const Color(0xFF14B8A6), tint: const Color(0xFFCCFBF1)),
          ],
        ),
        const SizedBox(height: 24),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              'Upcoming',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppTheme.charcoal),
            ),
            if (active.length > 4)
              TextButton(onPressed: () {}, child: const Text('View all')),
          ],
        ),
        const SizedBox(height: 8),
        if (active.isEmpty)
          const EmptyState(message: 'No active appointments yet. Keep your profile complete and available to receive bookings.')
        else
          ...active.take(4).map((b) => BookingTile(
                booking: b,
                onTap: () => _openDetail(context, b),
              )),
      ],
    );
  }

  Widget _kycBanner(BuildContext context, AppUser user) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFFFFBEB),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFFCD34D)),
      ),
      child: Row(
        children: [
          const Icon(Icons.verified_user_outlined, color: Color(0xFFB45309)),
          const SizedBox(width: 10),
          const Expanded(
            child: Text(
              'Profile not verified yet. Upload your KYC & professional documents to get the Verified badge.',
              style: TextStyle(fontSize: 12.5, color: Color(0xFF92400E)),
            ),
          ),
        ],
      ),
    );
  }

  void _openDetail(BuildContext context, Booking b) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => AppointmentDetailScreen(booking: b)),
    );
  }
}
