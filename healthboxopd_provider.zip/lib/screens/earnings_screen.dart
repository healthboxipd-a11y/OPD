import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../state/app_state.dart';
import '../state/auth_state.dart';
import '../utils/formatters.dart';
import '../utils/theme.dart';
import '../widgets/common.dart';
import '../widgets/status_badge.dart';

class EarningsScreen extends StatelessWidget {
  const EarningsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final auth = context.watch<AuthState>();
    final user = auth.user;

    final completedPaid = app.bookings
        .where((b) => b.status == 'completed' && b.paymentPaid)
        .toList();
    final total = completedPaid.fold<num>(0, (s, b) => s + (b.amount ?? 0));

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
          'Earnings',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppTheme.charcoal),
        ),
        const SizedBox(height: 6),
        const Text('Completed visits and amounts received.',
            style: TextStyle(fontSize: 13, color: AppTheme.muted)),
        const SizedBox(height: 16),
        GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: 2,
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: 1.5,
          children: [
            StatCard(label: 'Total earned (paid)', value: formatINR(total), icon: Icons.account_balance_wallet, bar: AppTheme.emerald, tint: const Color(0xFFD1FAE5)),
            StatCard(label: 'Completed visits', value: '${completedPaid.length}', icon: Icons.check_circle_outline, bar: AppTheme.primary, tint: const Color(0xFFE0EBFF)),
          ],
        ),
        const SizedBox(height: 20),
        const Text('Settlement history',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppTheme.charcoal)),
        const SizedBox(height: 4),
        const Text('Requests you submit appear in admin Payments & Invoices.',
            style: TextStyle(fontSize: 12, color: AppTheme.muted)),
        const SizedBox(height: 12),
        if (app.settlements.isEmpty)
          const EmptyState(message: 'No settlement requests yet.', icon: Icons.receipt_long_outlined)
        else
          ...app.settlements.map((s) => Card(
                margin: const EdgeInsets.only(bottom: 12),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(s.invoiceNo.isNotEmpty ? s.invoiceNo : 'Settlement',
                              style: const TextStyle(fontWeight: FontWeight.w700, color: AppTheme.charcoal)),
                          const Spacer(),
                          StatusBadge(status: s.status),
                        ],
                      ),
                      const SizedBox(height: 8),
                      _line('Gross', formatINR(s.gross)),
                      _line('Eligible payout', formatINR(s.eligible)),
                      if (s.finalPayout != null)
                        Container(
                          margin: const EdgeInsets.only(top: 6),
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(color: const Color(0xFFD1FAE5), borderRadius: BorderRadius.circular(10)),
                          child: Row(
                            children: [
                              const Text('Final payout',
                                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: Color(0xFF065F46))),
                              const Spacer(),
                              Text(formatINR(s.finalPayout),
                                  style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: Color(0xFF065F46))),
                            ],
                          ),
                        ),
                      if (s.isSettled && s.transferredOn.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.only(top: 8),
                          child: Text('Transferred on ${s.transferredOn}',
                              style: const TextStyle(fontSize: 12, color: AppTheme.emerald)),
                        ),
                    ],
                  ),
                ),
              )),
        const SizedBox(height: 16),
        if (user != null && (user.bankIfsc.isEmpty || user.bankAccountNumber.isEmpty))
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: const Color(0xFFFFFBEB),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFFFCD34D)),
            ),
            child: const Text(
              'Add bank details in Profile before requesting a settlement.',
              style: TextStyle(fontSize: 12.5, color: Color(0xFF92400E)),
            ),
          ),
      ],
    );
  }

  Widget _line(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(
        children: [
          Text(label, style: const TextStyle(fontSize: 13, color: AppTheme.muted)),
          const Spacer(),
          Text(value, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppTheme.charcoal)),
        ],
      ),
    );
  }
}
