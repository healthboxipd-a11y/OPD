import 'package:flutter/material.dart';

import '../models/booking.dart';
import '../utils/formatters.dart';
import '../utils/theme.dart';
import 'status_badge.dart';

/// A tappable booking/assignment card mirroring the website BookingCard.
class BookingTile extends StatelessWidget {
  const BookingTile({super.key, required this.booking, this.onTap});
  final Booking booking;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Wrap(
                spacing: 8,
                runSpacing: 6,
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  Text(
                    serviceName(booking.service),
                    style: const TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: 14,
                      color: AppTheme.charcoal,
                    ),
                  ),
                  if (booking.appointmentId.isNotEmpty)
                    Text(
                      '#${formatUniqueId(booking.appointmentId)}',
                      style: const TextStyle(
                        fontFamily: 'monospace',
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: AppTheme.primary,
                      ),
                    ),
                  StatusBadge(status: booking.status),
                  StatusBadge(status: booking.paymentStatus),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                booking.patientName.isNotEmpty
                    ? booking.patientName
                    : 'Patient',
                style: const TextStyle(fontSize: 14, color: AppTheme.charcoal),
              ),
              const SizedBox(height: 4),
              Text(
                '${booking.bookingDate.isEmpty ? "Date n/a" : booking.bookingDate} · '
                '${booking.timeSlot.isEmpty ? "Slot n/a" : booking.timeSlot}'
                '${booking.centerName.isNotEmpty ? " · ${booking.centerName}" : ""}'
                ' · ${formatINR(booking.amount)}',
                style: const TextStyle(fontSize: 12, color: AppTheme.muted),
              ),
              if (booking.address.isNotEmpty) ...[
                const SizedBox(height: 4),
                Row(
                  children: [
                    const Icon(Icons.place_outlined, size: 13, color: AppTheme.primary),
                    const SizedBox(width: 4),
                    Expanded(
                      child: Text(
                        booking.address,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 12, color: AppTheme.muted),
                      ),
                    ),
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
